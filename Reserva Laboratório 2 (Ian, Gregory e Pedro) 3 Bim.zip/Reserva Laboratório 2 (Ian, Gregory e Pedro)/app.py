import sqlite3
from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

DB_PATH = Path(__file__).with_name("reservas.db")
SCHEMA_PATH = Path(__file__).with_name("banco.sql")
TURNOS = ["Manhã", "Tarde", "Noite"]


# Com Banco de Dados
def get_conn():
    conn = sqlite3.connect(DB_PATH, isolation_level=None)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_conn()
    try:
        conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
    finally:
        conn.close()


def listar_laboratorios():
    conn = get_conn()
    try:
        return conn.execute(
            "SELECT ID, Nome, Capacidade FROM Laboratorios ORDER BY Nome"
        ).fetchall()
    finally:
        conn.close()


def listar_reservas():
    """READ com INNER JOIN: mostra o nome do laboratório, não o ID."""
    conn = get_conn()
    try:
        return pd.read_sql_query(
            """
            SELECT r.ID,
                   l.Nome           AS Laboratório,
                   l.Capacidade     AS Capacidade,
                   r.Nome_Professor AS Professor,
                   r.Data           AS Data,
                   r.Turno          AS Turno
            FROM Reservas r
            INNER JOIN Laboratorios l ON r.Lab_ID = l.ID
            ORDER BY r.Data, r.Turno, l.Nome
            """,
            conn,
        )
    finally:
        conn.close()


def existe_conflito(conn, lab_id, data_iso, turno):
    """SELECT de verificação: já existe reserva para o mesmo lab, data e turno?"""
    linha = conn.execute(
        "SELECT 1 FROM Reservas WHERE Lab_ID = ? AND Data = ? AND Turno = ? LIMIT 1",
        (lab_id, data_iso, turno),
    ).fetchone()
    return linha is not None


def criar_reserva(lab_id, professor, data_iso, turno):
    """CREATE com motor de regra. Retorna True se reservou, False se houve conflito."""
    conn = get_conn()
    try:
        conn.execute("BEGIN IMMEDIATE")
        if existe_conflito(conn, lab_id, data_iso, turno):
            conn.execute("ROLLBACK")
            return False
        conn.execute(
            "INSERT INTO Reservas (Lab_ID, Nome_Professor, Data, Turno) VALUES (?, ?, ?, ?)",
            (lab_id, professor, data_iso, turno),
        )
        conn.execute("COMMIT")
        return True
    except sqlite3.IntegrityError:
        conn.execute("ROLLBACK")
        return False
    except Exception:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise
    finally:
        conn.close()


def excluir_reserva(reserva_id):
    conn = get_conn()
    try:
        conn.execute("DELETE FROM Reservas WHERE ID = ?", (reserva_id,))
    finally:
        conn.close()


# Interface
st.set_page_config(page_title="Reservas de Laboratório", layout="wide")
init_db()

st.title("Reservas de Laboratório")

laboratorios = listar_laboratorios()
mapa_labs = {lab_id: f"{nome} (cap. {cap})" for lab_id, nome, cap in laboratorios}

st.subheader("Nova reserva")
with st.form("form_reserva", clear_on_submit=False):
    col1, col2 = st.columns(2)
    with col1:
        lab_id = st.selectbox(
            "Laboratório",
            options=list(mapa_labs.keys()),
            format_func=lambda i: mapa_labs[i],
        )
        professor = st.text_input("Nome do professor")
    with col2:
        data_sel = st.date_input("Data", value=date.today(), min_value=date.today())
        turno = st.selectbox("Turno", TURNOS)
    enviado = st.form_submit_button("Reservar")

if enviado:
    if not professor.strip():
        st.warning("Informe o nome do professor.")
    else:
        ok = criar_reserva(lab_id, professor.strip(), data_sel.isoformat(), turno)
        if ok:
            st.success(
                f"Reserva confirmada: {mapa_labs[lab_id]} em "
                f"{data_sel.strftime('%d/%m/%Y')} ({turno})."
            )
        else:
            st.error(
                f"Laboratório ocupado: {mapa_labs[lab_id]} já está reservado em "
                f"{data_sel.strftime('%d/%m/%Y')} no turno da {turno.lower()}."
            )


st.subheader("Painel de reservas")
df = listar_reservas()
if df.empty:
    st.info("Nenhuma reserva cadastrada ainda.")
else:
    st.dataframe(df, hide_index=True, use_container_width=True)

    with st.expander("Cancelar uma reserva"):
        opcoes = {
            int(r.ID): f"{r.Laboratório} | {r.Data} | {r.Turno} | {r.Professor}"
            for r in df.itertuples()
        }
        escolhida = st.selectbox(
            "Reserva", options=list(opcoes.keys()), format_func=lambda i: opcoes[i]
        )
        if st.button("Cancelar reserva"):
            excluir_reserva(escolhida)
            st.rerun()
