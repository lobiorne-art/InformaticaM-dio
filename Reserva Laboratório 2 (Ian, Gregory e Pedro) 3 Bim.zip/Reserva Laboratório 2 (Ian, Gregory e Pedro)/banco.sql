-- Schema: Reservas de Laboratório (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Laboratorios (
    ID         INTEGER PRIMARY KEY AUTOINCREMENT,
    Nome       TEXT    NOT NULL UNIQUE,
    Capacidade INTEGER NOT NULL CHECK (Capacidade > 0)
);

CREATE TABLE IF NOT EXISTS Reservas (
    ID             INTEGER PRIMARY KEY AUTOINCREMENT,
    Lab_ID         INTEGER NOT NULL,
    Nome_Professor TEXT    NOT NULL,
    Data           TEXT    NOT NULL,  
    Turno          TEXT    NOT NULL CHECK (Turno IN ('Manhã', 'Tarde', 'Noite')),
    FOREIGN KEY (Lab_ID) REFERENCES Laboratorios (ID)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_reserva_unica
    ON Reservas (Lab_ID, Data, Turno);

INSERT INTO Laboratorios (Nome, Capacidade)
SELECT 'Lab de Informática 1', 30
WHERE NOT EXISTS (SELECT 1 FROM Laboratorios);

INSERT INTO Laboratorios (Nome, Capacidade)
SELECT 'Lab de Química', 20
WHERE (SELECT COUNT(*) FROM Laboratorios) = 1;

INSERT INTO Laboratorios (Nome, Capacidade)
SELECT 'Lab de Física', 25
WHERE (SELECT COUNT(*) FROM Laboratorios) = 2;

INSERT OR IGNORE INTO Laboratorios (Nome, Capacidade)
VALUES ('Lab de Informática 2', 35);
